/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PROJECT_Z;

import java.sql.Connection;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


/*
 * @author Oliuuer 
 */
public class GestorContactos extends Contacto{
    // nuestros atributos
    
    protected List<Contacto> lista = new ArrayList<>();
    protected final String archivo = "contactos.txt";
    
    public GestorContactos(String nombre, String telefono, String email) {
        super(nombre, telefono, email);
    }
    
    void cargarContactos(){
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 3) {
                    lista.add(new Contacto(datos[0], datos[1], datos[2]));
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo cargar contactos (EL ARCHIVO NO EXISTE).");
        }
    }
    
    void guardarContactos(){
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            for (Contacto c : lista) {
                bw.write(c.getNombre() + "," + c.getTelefono() + "," + c.getEmail());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al guardar contactos.");
        }
    }
    
    void agregar(Contacto c){
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = (Connection) DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/gestor_contactos",
            "root",
            "123579" // mi contraseña MySQL
        );

        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO contactos (nombre, telefono, email) VALUES (?, ?, ?)"
        );
        ps.setString(1, c.getNombre());
        ps.setString(2, c.getTelefono());
        ps.setString(3, c.getEmail());

        ps.executeUpdate();
        ps.close();
        con.close();

        System.out.println("TRUE. Contacto guardado en MySQL correctamente.");
    } catch (Exception e) {
        System.out.println("FALSE. Error al guardar en MySQL: " + e.getMessage());
    }

   
    lista.add(c);
    guardarContactos();
    }
    
    public Contacto buscar(String nombre){
        for (Contacto c : lista) {
            if (c.getNombre().equalsIgnoreCase(nombre)) {
                return c;
            }
        }
        return null;
    }
    
    void editar(String nombre, String nuevoTel, String nuevoEmail){
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/gestor_contactos",
            "root",
            "123579"  // mi contra
        );

        PreparedStatement ps = con.prepareStatement(
            "UPDATE contactos SET telefono = ?, email = ? WHERE nombre = ?"
        );
        ps.setString(1, nuevoTel);
        ps.setString(2, nuevoEmail);
        ps.setString(3, nombre);

        int filas = ps.executeUpdate();

        if (filas > 0) {
            System.out.println("TRUE. Contacto actualizado en MySQL.");
        } else {
            System.out.println("FALSE. Contacto no encontrado.");
        }

        ps.close();
        con.close();
    } catch (Exception e) {
        System.out.println("Error al editar contacto: " + e.getMessage());
    }
    }
    
    void eliminar(String nombre) {
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/gestor_contactos",
            "root",
            "123579" // mi contra
        );

        PreparedStatement ps = con.prepareStatement("DELETE FROM contactos WHERE nombre = ?");
        ps.setString(1, nombre);
        int filas = ps.executeUpdate();

        if (filas > 0) {
            System.out.println("TRUE. Contacto eliminado de MySQL.");
        } else {
            System.out.println("FALSE. No se encontró el contacto con ese nombre.");
        }

        ps.close();
        con.close();
    } catch (Exception e) {
        System.out.println("Error al eliminar contacto: " + e.getMessage());
    }
    }
    
    void mostrarTodos() {
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/gestor_contactos",
            "root",
            "123579" //mi contra
        );

        PreparedStatement ps = con.prepareStatement("SELECT * FROM contactos");
        java.sql.ResultSet rs = ps.executeQuery();

        System.out.println("\n=== CONTACTOS REGISTRADOS ===");
        while (rs.next()) {
            System.out.println(
                rs.getString("nombre") + " | " +
                rs.getString("telefono") + " | " +
                rs.getString("email")
            );
        }

        rs.close();
        ps.close();
        con.close();
    } catch (Exception e) {
        System.out.println("FALSE. Error al mostrar contactos: " + e.getMessage());
    }
    }
}
